package com.example.sensors;

import android.annotation.SuppressLint;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.BatteryManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.PowerManager;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.Locale;
import java.util.Random;

public class MainActivity extends AppCompatActivity implements SensorEventListener {

    // ---------------- ตัวแปรหลัก ----------------
    SensorManager sensorManager;
    private static final int POLL_INTERVAL = 500;
    private final Handler hdr = new Handler();
    private PowerManager.WakeLock wl;
    SensorInfo sensor_info = new SensorInfo();
    Boolean shown_dialog = false;
    private static final int shake_threshold = 15;

    // random หมายเลขเซียมซี
    private final Random random = new Random();
    private static final int MAX_FORTUNE_NUMBER = 10;

    // รูปกระปุกเซียมซี
    private ImageView imageFortuneBox;

    // Runnable ทำงานทุก 0.5 วินาที (เหมือน thread)
    private final Runnable pollTask = new Runnable() {
        public void run() {
            showDialog();
            hdr.postDelayed(pollTask, POLL_INTERVAL);
        }
    };

    @SuppressLint("InvalidWakeLockTag")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        sensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);

        // ผูก ImageView กระปุกเซียมซี (ต้องมีใน activity_main.xml)
        imageFortuneBox = findViewById(R.id.imageFortuneBox);

        if (sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER) == null) {
            TextView text1 = findViewById(R.id.textView1);
            text1.setText(R.string.accelerometer_na);
        }

        PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
        wl = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "SensorsInfo:WakeLock");
    }

    // ---------------- onAccuracyChanged ----------------
    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {
        // ไม่ได้ใช้
    }

    // ---------------- ข้อ 4: onSensorChanged เก็บค่าอย่างเดียว ----------------
    @Override
    public void onSensorChanged(SensorEvent event) {
        int type = event.sensor.getType();

        if (type == Sensor.TYPE_ACCELEROMETER) {
            sensor_info.accX = event.values[0];
            sensor_info.accY = event.values[1];
            sensor_info.accZ = event.values[2];
        }
        if (type == Sensor.TYPE_GRAVITY) {
            sensor_info.graX = event.values[0];
            sensor_info.graY = event.values[1];
            sensor_info.graZ = event.values[2];
        }
        if (type == Sensor.TYPE_GYROSCOPE) {
            sensor_info.gyrX = event.values[0];
            sensor_info.gyrY = event.values[1];
            sensor_info.gyrZ = event.values[2];
        }
        if (type == Sensor.TYPE_LIGHT) {
            sensor_info.light = event.values[0];
        }
        if (type == Sensor.TYPE_LINEAR_ACCELERATION) {
            sensor_info.laccX = event.values[0];
            sensor_info.laccY = event.values[1];
            sensor_info.laccZ = event.values[2];
        }
        if (type == Sensor.TYPE_MAGNETIC_FIELD) {
            sensor_info.magX = event.values[0];
            sensor_info.magY = event.values[1];
            sensor_info.magZ = event.values[2];
        }
        // noinspection deprecation
        if (type == Sensor.TYPE_ORIENTATION) {
            sensor_info.orX = event.values[0];
            sensor_info.orY = event.values[1];
            sensor_info.orZ = event.values[2];
        }
        if (type == Sensor.TYPE_PROXIMITY) {
            sensor_info.proximity = event.values[0];
        }
        if (type == Sensor.TYPE_ROTATION_VECTOR) {
            sensor_info.rotX = event.values[0];
            sensor_info.rotY = event.values[1];
            sensor_info.rotZ = event.values[2];
        }
        if (type == Sensor.TYPE_AMBIENT_TEMPERATURE) {
            sensor_info.ambientTemp = event.values[0];
        }
    }

    // ---------------- ข้อ 5: ใช้ Handler ตรวจ threshold + แสดง dialog ----------------
    // อัปเดต TextView + ตรวจเขย่า + สุ่มเซียมซี + animation กระปุกเขย่า
    public void showDialog() {

        String message1 = String.format(Locale.getDefault(),
                "Accelerometer (m/s^2): \n x: %.2f \n y: %.2f \n z: %.2f",
                sensor_info.accX, sensor_info.accY, sensor_info.accZ);
        TextView text1 = findViewById(R.id.textView1);
        text1.setText(message1);

        String message2 = String.format(Locale.getDefault(),
                "Gravity (m/s^2): \n x: %.2f \n y: %.2f \n z: %.2f",
                sensor_info.graX, sensor_info.graY, sensor_info.graZ);
        TextView text2 = findViewById(R.id.textView2);
        text2.setText(message2);

        String message3 = String.format(Locale.getDefault(),
                "Gyroscope (rad/s) : \n x: %.2f \n y: %.2f \n z: %.2f",
                sensor_info.gyrX, sensor_info.gyrY, sensor_info.gyrZ);
        TextView text3 = findViewById(R.id.textView3);
        text3.setText(message3);

        String message4 = String.format(Locale.getDefault(),
                "Light (lux) : %.2f", sensor_info.light);
        TextView text4 = findViewById(R.id.textView4);
        text4.setText(message4);

        String message5 = String.format(Locale.getDefault(),
                "Linear Acc (m/s^2): \n x: %.2f \n y: %.2f \n z: %.2f",
                sensor_info.laccX, sensor_info.laccY, sensor_info.laccZ);
        TextView text5 = findViewById(R.id.textView5);
        text5.setText(message5);

        String message6 = String.format(Locale.getDefault(),
                "Magnetic (microT) : \n x: %.2f \n y: %.2f \n z: %.2f",
                sensor_info.magX, sensor_info.magY, sensor_info.magZ);
        TextView text6 = findViewById(R.id.textView6);
        text6.setText(message6);

        String message7 = String.format(Locale.getDefault(),
                "Orientation (deg) : \n z: %.2f \n x: %.2f \n y: %.2f",
                sensor_info.orX, sensor_info.orY, sensor_info.orZ);
        TextView text7 = findViewById(R.id.textView7);
        text7.setText(message7);

        String message8 = String.format(Locale.getDefault(),
                "Proximity (cm) : %.2f", sensor_info.proximity);
        TextView text8 = findViewById(R.id.textView8);
        text8.setText(message8);

        String message9 = String.format(Locale.getDefault(),
                "Rotation Vector : \n x: %.2f \n y: %.2f \n z: %.2f",
                sensor_info.rotX, sensor_info.rotY, sensor_info.rotZ);
        TextView text9 = findViewById(R.id.textView9);
        text9.setText(message9);

        // ----- เช็กว่ามีการเขย่ามั้ย (เทียบ threshold) -----
        boolean isShaking =
                (Math.abs(sensor_info.accX) > shake_threshold) ||
                        (Math.abs(sensor_info.accY) > shake_threshold) ||
                        (Math.abs(sensor_info.accZ) > shake_threshold);

        if (isShaking) {

            // เล่น animation เขย่ารูปกระปุก
            playShakeAnimation();

            // กัน dialog ขึ้นซ้ำ ๆ
            if (!shown_dialog) {
                shown_dialog = true;

                // สุ่มเลขเซียมซี 1–10
                int fortuneNumber = random.nextInt(MAX_FORTUNE_NUMBER) + 1;

                String title = "เซียมซีหมายเลข " + fortuneNumber;
                String fortuneMessage = getFortuneMessage(fortuneNumber);

                AlertDialog.Builder viewDialog = createFortuneDialog(title, fortuneMessage);
                viewDialog.show();
            }
        }
    }

    // เล่น animation เขย่ารูปกระปุกเซียมซี
    private void playShakeAnimation() {
        if (imageFortuneBox != null) {
            Animation shake = AnimationUtils.loadAnimation(this, R.anim.shake);
            imageFortuneBox.startAnimation(shake);
        }
    }

    // สร้าง AlertDialog สำหรับเซียมซี
    private AlertDialog.Builder createFortuneDialog(String title, String message) {
        AlertDialog.Builder viewDialog = new AlertDialog.Builder(this);
        viewDialog.setIcon(android.R.drawable.btn_star_big_on);
        viewDialog.setTitle(title);
        viewDialog.setMessage(message);
        viewDialog.setPositiveButton("ปิด", (dialog, which) -> {
            dialog.dismiss();
            shown_dialog = false;
        });
        return viewDialog;
    }

    // ข้อความคำทำนาย
    private String getFortuneMessage(int number) {
        switch (number) {
            case 1:
                return "วันนี้คุณจะมีพลังบวกเยอะมาก ทุกอย่างที่ลงมือทำจะราบรื่นกว่าที่คิด แค่รักษาอารมณ์ดีไว้ก็พอ";
            case 2:
                return "อย่าเพิ่งเครียดเรื่องเงินมากไป บางอย่างค่อย ๆ จัดการทีละเรื่อง เดี๋ยวมันจะเข้าที่เอง";
            case 3:
                return "มีโอกาสเริ่มต้นอะไรใหม่ ๆ ที่อาจเปลี่ยนชีวิตได้ ลองเปิดใจและกล้าก้าวออกจากจุดเดิมดูนะ";
            case 4:
                return "วันนี้จะมีคนเข้ามาช่วยเหลือหรือให้คำแนะนำดี ๆ อย่าลังเลที่จะเปิดรับ เพราะมันอาจเปลี่ยนมุมมองของคุณได้เลย";
            case 5:
                return "สิ่งที่คุณพยายามมานานกำลังเริ่มเห็นผล อย่าหยุดกลางทาง แค่ก้าวต่ออีกนิดก็ใกล้สำเร็จแล้ว";
            case 6:
                return "อาจมีเรื่องเล็ก ๆ มาทำให้หงุดหงิด ลองพักหายใจลึก ๆ แล้วปล่อยผ่าน คุณจะรู้สึกดีขึ้นเยอะ";
            case 7:
                return "มีแนวโน้มว่าจะได้รับข่าวดี หรือได้เจอคนที่ทำให้ยิ้มได้ทั้งวัน เก็บโมเมนต์ดี ๆ นี้ไว้เป็นพลังใจนะ";
            case 8:
                return "ระวังพูดอะไรเร็วไป ลองคิดอีกสักนิดก่อนตอบ จะช่วยหลีกเลี่ยงความเข้าใจผิดและทำให้ดูมีวุฒิภาวะมากขึ้น";
            case 9:
                return "สิ่งที่คิดไว้นานเริ่มเป็นรูปเป็นร่างแล้ว อย่ากลัวที่จะลงมือจริงจัง ผลลัพธ์อาจดีกว่าที่คาดไว้";
            case 10:
            default:
                return "วันนี้อย่ากดดันตัวเองมากไป ทุกอย่างจะค่อย ๆ เข้าที่ แค่ใช้สติและทำให้ดีที่สุดก็พอ";
        }
    }


    // ---------------- Battery Info เดิม ----------------
    private final BroadcastReceiver batteryInfoReceiver = new BroadcastReceiver() {
        @SuppressLint("SetTextI18n")
        @Override
        public void onReceive(Context context, Intent intent) {
            int level = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, 0);
            int temperature = intent.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0);
            int voltage = intent.getIntExtra(BatteryManager.EXTRA_VOLTAGE, 0);

            TextView text = findViewById(R.id.textView11);
            text.setText(
                    "Battery Info:\n" +
                            "Level: " + level + "\n" +
                            "Temperature: " + temperature + "\n" +
                            "Voltage: " + voltage + "\n"
            );
        }
    };

    // ---------------- onResume / onPause ----------------
    @SuppressLint("WakelockTimeout")
    @Override
    protected void onResume() {
        super.onResume();
        sensorManager.registerListener(this,
                sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER),
                SensorManager.SENSOR_DELAY_NORMAL);
        sensorManager.registerListener(this,
                sensorManager.getDefaultSensor(Sensor.TYPE_GRAVITY),
                SensorManager.SENSOR_DELAY_NORMAL);
        sensorManager.registerListener(this,
                sensorManager.getDefaultSensor(Sensor.TYPE_GYROSCOPE),
                SensorManager.SENSOR_DELAY_NORMAL);
        sensorManager.registerListener(this,
                sensorManager.getDefaultSensor(Sensor.TYPE_LIGHT),
                SensorManager.SENSOR_DELAY_NORMAL);
        sensorManager.registerListener(this,
                sensorManager.getDefaultSensor(Sensor.TYPE_LINEAR_ACCELERATION),
                SensorManager.SENSOR_DELAY_NORMAL);
        sensorManager.registerListener(this,
                sensorManager.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD),
                SensorManager.SENSOR_DELAY_NORMAL);
        // noinspection deprecation
        sensorManager.registerListener(this,
                sensorManager.getDefaultSensor(Sensor.TYPE_ORIENTATION),
                SensorManager.SENSOR_DELAY_NORMAL);
        sensorManager.registerListener(this,
                sensorManager.getDefaultSensor(Sensor.TYPE_PROXIMITY),
                SensorManager.SENSOR_DELAY_NORMAL);
        sensorManager.registerListener(this,
                sensorManager.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR),
                SensorManager.SENSOR_DELAY_NORMAL);
        sensorManager.registerListener(this,
                sensorManager.getDefaultSensor(Sensor.TYPE_AMBIENT_TEMPERATURE),
                SensorManager.SENSOR_DELAY_NORMAL);

        this.registerReceiver(this.batteryInfoReceiver,
                new IntentFilter(Intent.ACTION_BATTERY_CHANGED));

        if (!wl.isHeld()) {
            wl.acquire();
        }
        hdr.postDelayed(pollTask, POLL_INTERVAL);
    }

    @Override
    protected void onPause() {
        super.onPause();
        sensorManager.unregisterListener(this);
        this.unregisterReceiver(this.batteryInfoReceiver);

        if (wl.isHeld()) {
            wl.release();
        }
        hdr.removeCallbacks(pollTask);
    }

    // ---------------- เก็บค่าจากเซนเซอร์ ----------------
    static class SensorInfo {
        float accX, accY, accZ;
        float graX, graY, graZ;
        float gyrX, gyrY, gyrZ;
        float light;
        float laccX, laccY, laccZ;
        float magX, magY, magZ;
        float orX, orY, orZ;
        float proximity;
        float rotX, rotY, rotZ;
        float ambientTemp;
    }
}